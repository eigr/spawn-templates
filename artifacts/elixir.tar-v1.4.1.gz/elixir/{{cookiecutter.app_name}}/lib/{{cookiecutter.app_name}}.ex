defmodule {{cookiecutter.app_module_name}} do
  @moduledoc false
end
