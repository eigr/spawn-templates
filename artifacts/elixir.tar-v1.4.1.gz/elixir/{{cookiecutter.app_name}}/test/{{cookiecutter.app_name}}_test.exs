defmodule {{cookiecutter.app_module_name}}Test do
  use ExUnit.Case
  doctest {{cookiecutter.app_module_name}}
end
